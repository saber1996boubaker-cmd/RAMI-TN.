RAMI TN - Android starter project

WHAT THIS IS
- An Android Studio project that wraps the included offline Rami card-game demo.
- Package name: com.ramitn.app
- Minimum Android: 6.0 (API 23)

IMPORTANT LIMITATION
This is NOT a built APK and does NOT yet include online multiplayer, room codes, or a server.
The included game is a local demo against a simple computer opponent. Real online play for
four phones requires a backend/realtime service and additional development.

HOW TO BUILD THE APK
1. Install Android Studio on a computer.
2. Open this extracted folder in Android Studio.
3. Let Gradle sync and install any requested Android SDK platform (API 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location, usually app/build/outputs/apk/debug/app-debug.apk.

You can then copy the APK to your Android phone and install it. Only install APKs you built
yourself or trust.
